// 页面准备时执行代码
$(document).ready(function() {
	// 更改当前时间
	$('.header-time').html(time('YYMMDDHHMMSS'));
	// 更改产量数据
	output('.margin-top-text');
	// 更改小时数据
	hours('.left-hours');
	// 更改一号机器人焊接数据
	machOne('.mach-one');
	// 更改二号机器人焊接数据
	machTwo('.mach-two');
	// 更改工单数据
	order('.rolling');
});

// 定时器
setInterval(function(){
	// 更改当前时间
	$('.header-time').html(time('YYMMDDHHMMSS'));
},1000)

setInterval(function(){
	output('.margin-top-text');
	hours('.left-hours');
	machOne('.mach-one');
	machTwo('.mach-two');
	order('.rolling');
},120000)





