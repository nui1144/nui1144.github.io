// 导航栏效果
layui.use('element', function() {
	var element = layui.element;
});

// var users = {user:'1144905960'}
// localStorage.setItem('login', JSON.stringify(users));
// var log = localStorage.getItem('login');
// var denglu = JSON.parse(log);
// if(denglu == null){
// 	console.log(1)
// 	window.location.href = "login.html"
// }