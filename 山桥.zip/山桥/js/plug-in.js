// 存储接口路径
localStorage.setItem('data', JSON.stringify('http://192.168.3.89/'));
var data1 = localStorage.getItem('data');
var jiekou = JSON.parse(data1);

// 获取当前时间
function time(a) {
	// a应为标签名(class/id)
	var now = new Date();
	var toLocaleString = now.toLocaleString();
	var currenttime = now.toLocaleTimeString();
	var getFullYear = now.getFullYear();
	var getMonth = now.getMonth() + 1;
	if (getMonth < 10) {
		getMonth = '0' + getMonth
	}
	var getDate = now.getDate();
	if (getDate < 10) {
		getDate = '0' + getDate
	}
	var getHours = now.getHours();
	if (getHours < 10) {
		getHours = '0' + getHours
	}
	var getMinutes = now.getMinutes();
	if (getMinutes < 10) {
		getMinutes = '0' + getMinutes
	}
	var getSeconds = now.getSeconds();
	if (getSeconds < 10) {
		getSeconds = '0' + getSeconds
	}
	if(a == 'YYMMDDHHMMSS'){
		return(getFullYear + '-' + getMonth + '-' + getDate + ' ' + getHours + ':' + getMinutes + ':' + getSeconds)
	}else if(a == 'YYMMDD'){
		return(getFullYear + '-' + getMonth + '-' + getDate)
	}else if(a == 'HHMMSS'){
		return(getHours + ':' + getMinutes + ':' + getSeconds)
	}else if(a == 'DD'){
		return(getDate)
	}else if(a == 'MM'){
		return(getMonth)
	}else if(a == 'YY'){
		return(getFullYear)
	}else if(a == 'YYMM'){
		return(getFullYear + '-' + getMonth)
	}else if(a == "MMDD"){
		return(getMonth + '-' + getDate)
	}
}

// 面板页替换产量数据
function output(a) {
	$.ajax({
		url: jiekou + "coutput",
		async: true,
		success: function(res) {
			for (var i = 0; i < $(a).length; i++) {
				$(a).eq(i).text(res.data[i])
			}
		}
	});
}

// 面板替换小时数据
function hours(a) {
	$.ajax({
		url: jiekou + "hcoutput",
		async: true,
		success: function(res) {
			var chartDom = document.querySelector(a);
			var myChart = echarts.init(chartDom);
			var option;
			option = {
				tooltip: {
					trigger: 'axis'
				},
				xAxis: {
					type: 'category',
					boundaryGap: false,
					data: res.data.hs
				},
				yAxis: {
					type: 'value'
				},
				series: [{
					type: 'line',
					data: res.data.hcs
				}, ]
			};
			option && myChart.setOption(option);
		}
	});
}

// 面板1号机器人焊接数据
function machOne(a) {
	$.ajax({
		url: jiekou + "output",
		async: true,
		success: function(res) {
			console.log(res.data)
			var chartDom = document.querySelector(a);
			var myChart = echarts.init(chartDom);
			var option;
			option = {
				// 大背景颜色
				backgroundColor: '#fff',
				series: [{
					name: '访问来源',
					type: 'pie',
					radius: ['30%', '70%'],
					data: [{
							value: res.data.dgd,
							name: res.data.dgd,
							itemStyle: {
								color: '#35a8f8'
							}
						},
						{
							value: res.data.mgd1,
							name: res.data.mgd1,
							itemStyle: {
								color: '#ffdf8a'
							}
						},
					],
					label: {
						normal: {
							textStyle: {
								color: '#333333',
								fontWeight: 'bold',
								fontSize: '30px'
							}
						}
					},
				}]
			};
			option && myChart.setOption(option);
		}
	});
}

// 面板2号机器人焊接数据
function machTwo(a) {
	$.ajax({
		url: jiekou + "output",
		async: true,
		success: function(res) {
			console.log(res.data)
			var chartDom = document.querySelector(a);
			var myChart = echarts.init(chartDom);
			var option;
			option = {
				// 大背景颜色
				backgroundColor: '#fff',
				series: [{
					name: '访问来源',
					type: 'pie',
					radius: ['30%', '70%'],
					data: [{
							value: res.data.mgd,
							name: res.data.mgd,
							itemStyle: {
								color: '#35a8f8'
							}
						},
						{
							value: res.data.dgd1,
							name: res.data.dgd1,
							itemStyle: {
								color: '#ffdf8a'
							}
						},
					],
					label: {
						normal: {
							textStyle: {
								color: '#333333',
								fontWeight: 'bold',
								fontSize: '30px'
							}
						}
					},
				}]
			};
			option && myChart.setOption(option);
		}
	});

}

// 面板工单数据更改
function order(a) {
	$.ajax({
		url: jiekou + "toutput",
		async: true,
		success: function(res) {
			var neirong = '';
			for (var i = 1; i <= parseInt(res.data.changdu); i++) {
				var add = "<li class='clearfix'><div class='fl yi'>" + res.data[i][0] +
					"</div><div class='fl er'>" + res.data[i][1] +
					"</div><div class='fl san'>" + res.data[i][2] +
					"</div><div class='fl si'>" + res.data[i][3] +
					"</div><div class='fl wu'><div class='layui-progress'>" +
					"<div class='layui-progress-bar' lay-percent='" + res.data[i][4] * 100 + "%'" +
					"></div></div></div><div class='fl liu'>" + res.data[i][5] +
					"</div></li>";
				neirong = neirong + add;
			}
			$(a + " ul").html(neirong);
			layui.use('element', function() {
				var element = layui.element;
			});
			if (parseInt(res.data.changdu) >= 7) {
				$(a).jCarouselLite({
					vertical: true,
					hoverPause: true,
					visible: 7,
					auto: 2000,
					speed: 300
				});
			}
		}
	});

}
